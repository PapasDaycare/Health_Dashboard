export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  email: string;
  address: string;
  notes?: string;
}

export interface Appointment {
  id: string;
  doctorId: string;
  date: string;
  time: string;
  type: string;
  notes?: string;
}