import React from 'react';
import { Doctor } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Phone, Mail, MapPin, Edit, Trash2 } from 'lucide-react';

interface DoctorCardProps {
  doctor: Doctor;
  onEdit: (doctor: Doctor) => void;
  onDelete: (id: string) => void;
}

export const DoctorCard: React.FC<DoctorCardProps> = ({ doctor, onEdit, onDelete }) => {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-200 bg-gradient-to-br from-blue-50 to-indigo-50 border-l-4 border-l-blue-500">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg font-bold text-gray-900">{doctor.name}</CardTitle>
            <p className="text-sm font-medium text-blue-600">{doctor.specialty}</p>
          </div>
          <div className="flex gap-1">
            <Button size="sm" variant="ghost" onClick={() => onEdit(doctor)}>
              <Edit className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={() => onDelete(doctor.id)}>
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        </div>
      </CardHeader>
       <CardContent className="space-y-2">
         <div className="flex items-center gap-2 text-sm">
           <Phone className="h-4 w-4 text-green-600 flex-shrink-0" />
           <span className="break-all">{doctor.phone}</span>
         </div>
         <div className="flex items-center gap-2 text-sm">
           <Mail className="h-4 w-4 text-blue-600 flex-shrink-0" />
           <span className="break-all">{doctor.email}</span>
         </div>
         <div className="flex items-start gap-2 text-sm">
           <MapPin className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
           <span className="break-words">{doctor.address}</span>
         </div>
       </CardContent>

    </Card>
  );
};