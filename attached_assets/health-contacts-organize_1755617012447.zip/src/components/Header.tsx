import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Heart, Stethoscope } from 'lucide-react';

interface HeaderProps {
  activeTab: 'doctors' | 'appointments';
  onTabChange: (tab: 'doctors' | 'appointments') => void;
  onAddDoctor: () => void;
  onAddAppointment: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  activeTab, 
  onTabChange, 
  onAddDoctor, 
  onAddAppointment 
}) => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-700 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4 md:py-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <Heart className="h-6 w-6 md:h-8 md:w-8" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold">Health Contact Organizer</h1>
              <p className="text-blue-100 text-sm md:text-base hidden sm:block">Manage your healthcare providers & appointments</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-4 w-full md:w-auto">
            <nav className="flex bg-white/10 rounded-lg p-1">
              <Button
                variant={activeTab === 'doctors' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => onTabChange('doctors')}
                className="text-white hover:text-gray-900 flex-1 sm:flex-none"
              >
                <Stethoscope className="h-4 w-4 mr-1 sm:mr-2" />
                <span className="text-xs sm:text-sm">Doctors</span>
              </Button>
              <Button
                variant={activeTab === 'appointments' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => onTabChange('appointments')}
                className="text-white hover:text-gray-900 flex-1 sm:flex-none"
              >
                <Plus className="h-4 w-4 mr-1 sm:mr-2" />
                <span className="text-xs sm:text-sm">Appointments</span>
              </Button>
            </nav>
            <Button
              onClick={activeTab === 'doctors' ? onAddDoctor : onAddAppointment}
              className="bg-white text-blue-600 hover:bg-blue-50 w-full sm:w-auto"
            >
              <Plus className="h-4 w-4 mr-2" />
              <span className="text-sm">Add {activeTab === 'doctors' ? 'Doctor' : 'Appointment'}</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};