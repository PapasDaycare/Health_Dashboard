import React, { useState } from 'react';
import { Appointment, Doctor } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface AppointmentFormProps {
  appointment?: Appointment;
  doctors: Doctor[];
  onSave: (appointment: Omit<Appointment, 'id'>) => void;
  onCancel: () => void;
}

export const AppointmentForm: React.FC<AppointmentFormProps> = ({ 
  appointment, 
  doctors, 
  onSave, 
  onCancel 
}) => {
  const [formData, setFormData] = useState({
    doctorId: appointment?.doctorId || '',
    date: appointment?.date || '',
    time: appointment?.time || '',
    type: appointment?.type || '',
    notes: appointment?.notes || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{appointment ? 'Edit Appointment' : 'New Appointment'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="doctorId">Doctor *</Label>
            <Select value={formData.doctorId} onValueChange={(value) => setFormData(prev => ({ ...prev, doctorId: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select a doctor" />
              </SelectTrigger>
              <SelectContent>
                {doctors.map(doctor => (
                  <SelectItem key={doctor.id} value={doctor.id}>
                    {doctor.name} - {doctor.specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
               <Label htmlFor="date">Date *</Label>
               <Input id="date" name="date" type="date" value={formData.date} onChange={handleChange} required />
             </div>
             <div>
               <Label htmlFor="time">Time *</Label>
               <Input id="time" name="time" type="time" value={formData.time} onChange={handleChange} required />
             </div>
           </div>
           <div>
             <Label htmlFor="type">Appointment Type *</Label>
             <Input id="type" name="type" value={formData.type} onChange={handleChange} required placeholder="e.g., Checkup, Consultation" />
           </div>
           <div>
             <Label htmlFor="notes">Notes</Label>
             <Textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} />
           </div>
           <div className="flex flex-col sm:flex-row gap-2 justify-end">
             <Button type="button" variant="outline" onClick={onCancel} className="w-full sm:w-auto">Cancel</Button>
             <Button type="submit" className="w-full sm:w-auto">Save</Button>
           </div>
        </form>
      </CardContent>
    </Card>
  );
};