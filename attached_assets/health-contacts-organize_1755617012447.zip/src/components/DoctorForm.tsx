import React, { useState } from 'react';
import { Doctor } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DoctorFormProps {
  doctor?: Doctor;
  onSave: (doctor: Omit<Doctor, 'id'>) => void;
  onCancel: () => void;
}

export const DoctorForm: React.FC<DoctorFormProps> = ({ doctor, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    name: doctor?.name || '',
    specialty: doctor?.specialty || '',
    phone: doctor?.phone || '',
    email: doctor?.email || '',
    address: doctor?.address || '',
    notes: doctor?.notes || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>{doctor ? 'Edit Doctor' : 'Add New Doctor'}</CardTitle>
      </CardHeader>
      <CardContent>
         <form onSubmit={handleSubmit} className="space-y-4">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
               <Label htmlFor="name">Name *</Label>
               <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
             </div>
             <div>
               <Label htmlFor="specialty">Specialty *</Label>
               <Input id="specialty" name="specialty" value={formData.specialty} onChange={handleChange} required />
             </div>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <div>
               <Label htmlFor="phone">Phone *</Label>
               <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} required />
             </div>
             <div>
               <Label htmlFor="email">Email</Label>
               <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} />
             </div>
           </div>
           <div>
             <Label htmlFor="address">Address</Label>
             <Input id="address" name="address" value={formData.address} onChange={handleChange} />
           </div>
           <div>
             <Label htmlFor="notes">Notes</Label>
             <Textarea id="notes" name="notes" value={formData.notes} onChange={handleChange} />
           </div>
           <div className="flex flex-col sm:flex-row gap-2 justify-end">
             <Button type="button" variant="outline" onClick={onCancel} className="w-full sm:w-auto">Cancel</Button>
             <Button type="submit" className="w-full sm:w-auto">Save</Button>
           </div>
         </form>
      </CardContent>
    </Card>
  );
};