import React, { useState } from 'react';
import { Doctor, Appointment } from '@/types';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { Header } from './Header';
import { DoctorCard } from './DoctorCard';
import { DoctorForm } from './DoctorForm';
import { AppointmentCard } from './AppointmentCard';
import { AppointmentForm } from './AppointmentForm';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

const AppLayout: React.FC = () => {
  const [doctors, setDoctors] = useLocalStorage<Doctor[]>('doctors', []);
  const [appointments, setAppointments] = useLocalStorage<Appointment[]>('appointments', []);
  const [activeTab, setActiveTab] = useState<'doctors' | 'appointments'>('doctors');
  const [showDoctorForm, setShowDoctorForm] = useState(false);
  const [showAppointmentForm, setShowAppointmentForm] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | undefined>();
  const [editingAppointment, setEditingAppointment] = useState<Appointment | undefined>();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSaveDoctor = (doctorData: Omit<Doctor, 'id'>) => {
    if (editingDoctor) {
      setDoctors(prev => prev.map(d => d.id === editingDoctor.id ? { ...doctorData, id: editingDoctor.id } : d));
    } else {
      const newDoctor = { ...doctorData, id: Date.now().toString() };
      setDoctors(prev => [...prev, newDoctor]);
    }
    setShowDoctorForm(false);
    setEditingDoctor(undefined);
  };

  const handleDeleteDoctor = (id: string) => {
    setDoctors(prev => prev.filter(d => d.id !== id));
    setAppointments(prev => prev.filter(a => a.doctorId !== id));
  };

  const handleSaveAppointment = (appointmentData: Omit<Appointment, 'id'>) => {
    if (editingAppointment) {
      setAppointments(prev => prev.map(a => a.id === editingAppointment.id ? { ...appointmentData, id: editingAppointment.id } : a));
    } else {
      const newAppointment = { ...appointmentData, id: Date.now().toString() };
      setAppointments(prev => [...prev, newAppointment]);
    }
    setShowAppointmentForm(false);
    setEditingAppointment(undefined);
  };

  const handleDeleteAppointment = (id: string) => {
    setAppointments(prev => prev.filter(a => a.id !== id));
  };

  const filteredDoctors = doctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredAppointments = appointments.filter(appointment => {
    const doctor = doctors.find(d => d.id === appointment.doctorId);
    return appointment.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
           (doctor && doctor.name.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  if (showDoctorForm) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <DoctorForm
          doctor={editingDoctor}
          onSave={handleSaveDoctor}
          onCancel={() => {
            setShowDoctorForm(false);
            setEditingDoctor(undefined);
          }}
        />
      </div>
    );
  }

  if (showAppointmentForm) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <AppointmentForm
          appointment={editingAppointment}
          doctors={doctors}
          onSave={handleSaveAppointment}
          onCancel={() => {
            setShowAppointmentForm(false);
            setEditingAppointment(undefined);
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onAddDoctor={() => setShowDoctorForm(true)}
        onAddAppointment={() => setShowAppointmentForm(true)}
      />
      
       <main className="container mx-auto px-4 py-6 md:py-8">
         <div className="mb-4 md:mb-6">
           <div className="relative max-w-full md:max-w-md">
             <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
             <Input
               placeholder={`Search ${activeTab}...`}
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="pl-10"
             />
           </div>
         </div>

         {activeTab === 'doctors' ? (
           <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
             {filteredDoctors.length === 0 ? (
               <div className="col-span-full text-center py-8 md:py-12">
                 <p className="text-gray-500 text-base md:text-lg px-4">No doctors found. Add your first doctor to get started!</p>
                 <Button onClick={() => setShowDoctorForm(true)} className="mt-4">
                   Add Doctor
                 </Button>
               </div>
             ) : (
               filteredDoctors.map(doctor => (
                 <DoctorCard
                   key={doctor.id}
                   doctor={doctor}
                   onEdit={(doctor) => {
                     setEditingDoctor(doctor);
                     setShowDoctorForm(true);
                   }}
                   onDelete={handleDeleteDoctor}
                 />
               ))
             )}
           </div>
         ) : (
           <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
             {filteredAppointments.length === 0 ? (
               <div className="col-span-full text-center py-8 md:py-12">
                 <p className="text-gray-500 text-base md:text-lg px-4">No appointments found. Schedule your first appointment!</p>
                 <Button onClick={() => setShowAppointmentForm(true)} className="mt-4">
                   Add Appointment
                 </Button>
               </div>
             ) : (
               filteredAppointments
                 .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                 .map(appointment => (
                   <AppointmentCard
                     key={appointment.id}
                     appointment={appointment}
                     doctor={doctors.find(d => d.id === appointment.doctorId)}
                     onEdit={(appointment) => {
                       setEditingAppointment(appointment);
                       setShowAppointmentForm(true);
                     }}
                     onDelete={handleDeleteAppointment}
                   />
                 ))
             )}
           </div>
         )}
       </main>

    </div>
  );
};

export default AppLayout;