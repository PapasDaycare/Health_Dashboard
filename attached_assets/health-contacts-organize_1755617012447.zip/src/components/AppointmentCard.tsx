import React from 'react';
import { Appointment, Doctor } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, Edit, Trash2, User } from 'lucide-react';

interface AppointmentCardProps {
  appointment: Appointment;
  doctor?: Doctor;
  onEdit: (appointment: Appointment) => void;
  onDelete: (id: string) => void;
}

export const AppointmentCard: React.FC<AppointmentCardProps> = ({ 
  appointment, 
  doctor, 
  onEdit, 
  onDelete 
}) => {
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200 bg-gradient-to-br from-green-50 to-emerald-50 border-l-4 border-l-green-500">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
             <CardTitle className="text-lg font-bold text-gray-900 break-words">{appointment.type}</CardTitle>
             {doctor && (
               <div className="flex items-center gap-1 text-sm text-green-600">
                 <User className="h-4 w-4 flex-shrink-0" />
                 <span className="break-words">{doctor.name} - {doctor.specialty}</span>
               </div>
             )}
           </div>
           <div className="flex gap-1 flex-shrink-0">
             <Button size="sm" variant="ghost" onClick={() => onEdit(appointment)}>
               <Edit className="h-4 w-4" />
             </Button>
             <Button size="sm" variant="ghost" onClick={() => onDelete(appointment.id)}>
               <Trash2 className="h-4 w-4 text-red-500" />
             </Button>
           </div>
         </div>
       </CardHeader>
       <CardContent className="space-y-2">
         <div className="flex items-center gap-2 text-sm">
           <Calendar className="h-4 w-4 text-blue-600 flex-shrink-0" />
           <span>{formatDate(appointment.date)}</span>
         </div>
         <div className="flex items-center gap-2 text-sm">
           <Clock className="h-4 w-4 text-purple-600 flex-shrink-0" />
           <span>{appointment.time}</span>
         </div>
         {appointment.notes && (
           <p className="text-sm text-gray-600 mt-2 break-words">{appointment.notes}</p>
         )}
       </CardContent>

    </Card>
  );
};